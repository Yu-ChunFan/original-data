
install.packages("vioplot")

library(vioplot)                                                    
setwd("C:\\Users\\lexb\\Desktop\\1378238016")                 
normal=50                                                           
tumor=374                                                           

rt=read.table("m6Aexp.txt",sep="\t",header=T,row.names=1,check.names=F)   
rt=t(rt)
rt=log2(rt+1)

pdf("vioplot.pdf",height=8,width=14)              
par(las=1,mar=c(4,5,3,3))
x=c(1:ncol(rt))
y=c(1:ncol(rt))
plot(x,y,
     xlim=c(0,82),ylim=c(min(rt),max(rt)*1.1),
     main="",xlab="", ylab="Gene expression",
     pch=21,
     cex.lab=1.5,
     col="white",
     xaxt="n")


for(i in 1:ncol(rt)){
  normalData=rt[1:normal,i]
  tumorData=rt[(normal+1):(normal+tumor),i]
  vioplot(normalData,at=3*(i-1),lty=1,add = T,col = 'blue')
  vioplot(tumorData,at=3*(i-1)+1,lty=1,add = T,col = 'red')
  wilcoxTest=wilcox.test(normalData,tumorData)
  p=round(wilcoxTest$p.value,3)
  mx=max(c(normalData,tumorData))
  lines(c(x=3*(i-1)+0.2,x=3*(i-1)+0.8),c(mx,mx))
  text(x=3*(i-1)+0.5, y=mx*1.05, labels=ifelse(p<0.001, paste0("p<0.001"), paste0("p=",p)), cex = 0.8)
}
text(seq(1,84,3.04),-0.5,xpd = NA,labels=colnames(rt),cex = 1,srt = 45,pos=2)
dev.off()

