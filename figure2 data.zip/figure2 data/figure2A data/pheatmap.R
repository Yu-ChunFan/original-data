
install.packages("pheatmap")

setwd("C:\\Users\\Administrator\\Desktop\\liver\\8.sigPeatmap")      
rt=read.table("geneSigExp.txt",sep="\t",header=T,row.names=1,check.names=F)
rt=log2(rt+1)

library(pheatmap)
Type=c(rep("N",50),rep("T",374)) 
names(Type)=colnames(rt)
Type=as.data.frame(Type)

pdf("heatmap.pdf",height=5,width=10)
pheatmap(rt, 
         annotation=Type, 
         color = colorRampPalette(c("green", "white", "red"))(50),
         cluster_cols =F,
         show_colnames = F,
         scale="row",
         fontsize = 10,
         fontsize_row=10,
         fontsize_col=3)
dev.off()

