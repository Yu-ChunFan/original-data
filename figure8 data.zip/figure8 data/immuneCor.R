
if (!requireNamespace("BiocManager", quietly = TRUE))
    install.packages("BiocManager")
BiocManager::install("limma")

install.packages("ggplot2")
install.packages("ggpubr")
install.packages("ggExtra")



library(limma)
library(ggplot2)
library(ggpubr)
library(ggExtra)
immFile="CIBERSORT-Results.txt"       
riskFile="allRisk.txt"                
pFilter=0.05       
setwd("C:\\Users\\Administrator\\Desktop\\m6a ganai\\34.immuneCor")     


immune=read.table(immFile, header=T, sep="\t", check.names=F, row.names=1)
immune=immune[immune[,"P-value"]<pFilter,]
immune=as.matrix(immune[,1:(ncol(immune)-3)])


group=sapply(strsplit(row.names(immune),"\\-"), "[", 4)
group=sapply(strsplit(group,""), "[", 1)
group=gsub("2", "1", group)
immune=immune[group==0,]
row.names(immune)=gsub("(.*?)\\-(.*?)\\-(.*?)\\-(.*?)\\-.*", "\\1\\-\\2\\-\\3", row.names(immune))
immune=avereps(immune)


risk=read.table(riskFile, header=T, sep="\t", check.names=F, row.names=1)


sameSample=intersect(row.names(immune),row.names(risk))
immune1=immune[sameSample,]
risk1=risk[sameSample,]


outTab=data.frame()
x=as.numeric(risk1[,"riskScore"])

for(j in colnames(immune1)){
	y=as.numeric(immune1[,j])
	if(sd(y)>0.001){
		df1=as.data.frame(cbind(x,y))
		corT=cor.test(x,y,method="spearman")
		cor=corT$estimate
		pValue=corT$p.value
		p1=ggplot(df1, aes(x, y)) + 
			xlab("Risk score")+ ylab(j)+
			geom_point()+ geom_smooth(method="lm",formula=y~x) + theme_bw()+
			stat_cor(method = 'spearman', aes(x =x, y =y))
		if(pValue<pFilter){
			pdf(file=paste0(j,".pdf"), width=5, height=4.6)
			print(p1)
			dev.off()
			outTab=rbind(outTab,cbind(Cell=j, pValue))
		}
	}
}
write.table(outTab,file="immuneCor.result.txt",sep="\t",row.names=F,quote=F)


